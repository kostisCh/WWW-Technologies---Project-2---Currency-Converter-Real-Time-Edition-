/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author constantine
 */
public class ReportLink {
    
    private String link;
	
	public ReportLink(String link){
		this.link = link;
	}
	
	public String getLink(){
		return link;
	}
    
}
